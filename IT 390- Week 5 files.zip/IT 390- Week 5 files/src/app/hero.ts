export class IT {
  id: number;
  name: string;
}
